export const placeholders = [
  {
    mainTitle: "KOMPLEKSY RELAKSACYJNE OLIVE RESORT",
    titleText1: "CHłOŃ I ODDYCHAJ",
    text1:
      'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.',
    titleText2: "INSPIRUJ SIĘ",
    text2:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for lorem ipsum will uncover many web sites still in their infancy.",
    link1: "Przejdź do zakładki z domami",
    makeAnAppointment: "UMÓW SIĘ NA SPOTKANIE",
    name: "IMIE",
    secondName: "NAZWISKO",
    phoneNumber: "NUMER TELEFONU",
    mail: "E-MAIL",
    comfirm:
      "Contrary to popular belief, Lorem Ipsum is not simply random text.",
    send: "WYŚLIJ",
    findHome:
      "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using Content here, content here, making it look like readable English.",
  },
  {
    mainTitle: "РЕЛАКСАЦІЙНІ КОМПЛЕКСИ ОЛИВКОВОГО",
    titleText1: "ОХОЛОДЖЕННЯ І ДИХАННЯ",
    text1:
      'Всупереч поширеній думці, Lorem Ipsum - це не просто випадковий текст. Він має коріння у творі класичної латинської літератури 45 року до н.е., тобто йому понад 2000 років. Річард МакКлінток, професор латинської мови в Гемпден-Сіднейському коледжі у Вірджинії, знайшов одне з найбільш маловідомих латинських слів, consectetur, з уривку Lorem Ipsum, і, переглянувши цитати цього слова в класичній літературі, виявив безсумнівне джерело. Lorem Ipsum походить з розділів 1.10.32 та 1.10.33 книги Цицерона "De Finibus Bonorum et Malorum" ("Про межі добра і зла"), написаної в 45 році до нашої ери. Ця книга є трактатом з теорії етики, дуже популярним в епоху Відродження. Перший рядок Lorem Ipsum, "Lorem ipsum dolor sit amet...", походить з рядка в розділі 1.10.32. Стандартний фрагмент Lorem Ipsum, який використовується з 1500-х років, відтворено нижче для тих, хто цікавиться. Розділи 1.10.32 і 1.10.33 з "De Finibus Bonorum et Malorum" Цицерона також відтворені в їх точному оригінальному вигляді, супроводжувані англійськими версіями з перекладу Г. Ракхема 1914 року.',
    titleText2: "НАДИХАТИСЯ",
    text2:
      'Давно відомий факт, що читач буде відволікатися на читабельний вміст сторінки, дивлячись на її макет. Сенс використання Lorem Ipsum полягає в тому, що він має більш-менш нормальний розподіл літер, на відміну від використання "Зміст тут, зміст тут", що робить його схожим на читабельну англійську мову. Багато настільних видавничих пакетів і редакторів веб-сторінок зараз використовують Lorem Ipsum як типовий текст за замовчуванням, і пошук за запитом "lorem ipsum" відкриє багато веб-сайтів, які ще перебувають у зародковому стані.',
    link1: 'Перейдіть на вкладку "Додому',
    makeAnAppointment: "ЗАПИСАТИСЯ НА ПРИЙОМ",
    name: "ІМЯ",
    secondName: "ПІБ",
    phoneNumber: "НОМЕР ТЕЛЕФОНУ",
    mail: "ЕЛЕКТРОННА ПОШТА",
    comfirm:
      "Всупереч поширеній думці, Lorem Ipsum - це не просто випадковий текст.",
    send: "ВІДПРАВ",
    findHome:
      "Давно відомий факт, що читач буде відволікатися на читабельний вміст сторінки, дивлячись на її макет.",
  },
  {
    mainTitle: "РЕЛАКСАЦИОННЫЕ КОМПЛЕКСЫ ОЛИВК",
    titleText1: "ОХЛАЖДАТЬСЯ И ДЫШАТЬ",
    text1:
      'Вопреки распространенному мнению, Lorem Ipsum - это не просто случайный текст. Его корни уходят в классическую латинскую литературу 45 года до н.э., т.е. ему уже более 2000 лет. Ричард Макклинток, преподаватель латинского языка в колледже Хэмпден-Сидней (штат Вирджиния), нашел одно из самых непонятных латинских слов, consectetur, в отрывке из Lorem Ipsum, и, просмотрев цитаты этого слова в классической литературе, обнаружил несомненный источник. Lorem Ipsum взят из разделов 1.10.32 и 1.10.33 книги Цицерона "О крайностях добра и зла" ("de Finibus Bonorum et Malorum"), написанной в 45 году до нашей эры. Эта книга представляет собой трактат по теории этики, очень популярный в эпоху Возрождения. Первая строка Lorem Ipsum - "Lorem ipsum dolor sit amet..." - происходит из строки раздела 1.10.32. Ниже для интересующихся приводится стандартный фрагмент Lorem Ipsum, используемый с 1500-х годов. Разделы 1.10.32 и 1.10.33 из "De Finibus Bonorum et Malorum" Цицерона также воспроизведены в оригинале и сопровождаются английскими версиями из перевода Г. Рэкхема 1914 года.',
    titleText2: "ВДОХНОВИТЬСЯ",
    text2:
      'Давно известно, что читатель отвлекается от читаемого содержания страницы, глядя на ее макет. Смысл использования Lorem Ipsum заключается в том, что он имеет более или менее нормальное распределение букв, в отличие от использования "Содержание здесь, содержание здесь", что делает его похожим на читаемый английский язык. В настоящее время многие настольные издательские пакеты и редакторы веб-страниц используют Lorem Ipsum в качестве типового текста по умолчанию, а поиск по запросу "lorem ipsum" позволяет найти множество веб-сайтов, находящихся еще в стадии становления.',
    link1: "Перейдите на вкладку Дома",
    makeAnAppointment: "ЗАПИСАТИСЯ НА ПРИЙОМ",
    name: "НАЗВАНИЕ",
    secondName: "НАЗВАНИЕ",
    phoneNumber: "НОМЕР ТЕЛЕФОНА",
    mail: "E-MAIL",
    comfirm:
      "Вопреки распространенному мнению, Lorem Ipsum - это не просто случайный текст.",
    send: "ОТПРАВ",
    findHome:
      "Давно известно, что читатель отвлекается от читаемого содержания страницы, глядя на ее макет.",
  },
];
